
MO1 – Password Manager v2.0 (Full Package)

Run:
  pip install -r requirements.txt
  python mo1_launcher.py

Build EXE:
  .\build.bat
  -> dist\MO1.exe

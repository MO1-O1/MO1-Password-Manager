# Build MO1.exe
if (-not (pip show pyinstaller 2>$null)) { pip install pyinstaller }
Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue
Remove-Item -Force MO1.spec -ErrorAction SilentlyContinue
pyinstaller --onefile --windowed --name "MO1" --icon app_icon.ico mo1_launcher.py
Write-Host "DONE. Output: dist\MO1.exe"

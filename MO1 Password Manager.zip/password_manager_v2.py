#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MO1 Password Manager v2.0
(Full code bundled again to ensure package completeness)
"""
import os, sys, json, time, csv, base64, threading, random, string, io
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog

VERSION = "v2.0"

try:
    import pyperclip
except Exception:
    pyperclip = None

try:
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.backends import default_backend
    from cryptography.fernet import Fernet, InvalidToken
    CRYPTO_OK = True
except Exception:
    CRYPTO_OK = False

try:
    import qrcode
    from PIL import Image, ImageTk
    QR_OK = True
except Exception:
    QR_OK = False

try:
    import pystray
    from PIL import Image as PILImage, ImageDraw
    TRAY_OK = True
except Exception:
    TRAY_OK = False

APP_NAME_AR = "مدير كلمات السر - MO1"
APP_NAME_EN = "Password Manager - MO1"
DATA_DIR = Path.home() / ".pmgr_mo1"
DATA_DIR.mkdir(exist_ok=True)
CONF_FILE = DATA_DIR / "config.json"
DB_FILE = DATA_DIR / "vault.enc"
BACKUP_EXT = ".pmgr"

DEFAULTS = {"theme":"blue","idle_minutes":5,"clipboard_seconds":30,"reveal_seconds":5,"lang":"en"}
WEAK_PASSWORDS = {"123456","password","123456789","qwerty","abc123","111111","123123","000000","iloveyou","1234","12345","qwerty123","1q2w3e4r","admin","letmein"}

T = {
    "ar": {
        "enter_master": "أدخل كلمة المرور الرئيسية:",
        "create_master": "أنشئ كلمة مرور رئيسية قوية:",
        "confirm": "أعد إدخال كلمة المرور:",
        "mismatch": "الكلمتان غير متطابقتين.",
        "too_short": "الطول قصير. اختر 8 أحرف على الأقل.",
        "need_crypto": "تحتاج مكتبة 'cryptography'.\\nثبت:\\npip install cryptography",
        "bad_master": "كلمة المرور الرئيسية غير صحيحة.",
        "sidebar_all": "كل العناصر",
        "sidebar_tags": "الوسوم",
        "search": "بحث… (استخدم #وسم للتصفية)",
        "add_manual": "إضافة",
        "generate": "توليد",
        "edit": "تعديل",
        "delete": "حذف",
        "copy": "نسخ",
        "copy_all": "نسخ الكل",
        "reveal": "إظهار",
        "qr": "QR",
        "mini": "Mini",
        "tray": "إلى الشريط",
        "lock": "قفل",
        "settings": "إعدادات",
        "import": "استيراد CSV",
        "export": "تصدير CSV",
        "backup": "نسخة احتياطية",
        "restore": "استعادة",
        "desc": "الوصف",
        "user": "المستخدم/الإيميل",
        "pwd_hidden": "كلمة السر (مخفية)",
        "strength": "القوة",
        "created": "الإنشاء",
        "updated": "التعديل",
        "notes": "ملاحظات",
        "none": "—",
        "saved": "تم الحفظ.",
        "select_first": "اختر عنصرًا أولًا.",
        "delete_confirm": "حذف '{desc}'؟",
        "need_pyperclip": "تحتاج pyperclip للنسخ.\\npip install pyperclip",
        "copied": "تم النسخ. سيتم مسح الحافظة بعد {sec} ثانية.",
        "reveal_msg": "سيتم إخفاؤها بعد {sec} ث.",
        "csv_exported": "تم تصدير CSV.",
        "csv_imported": "تم الاستيراد: {n} عنصر.",
        "import_failed": "فشل الاستيراد: {err}",
        "import_auth": "أدخل كلمة المرور الرئيسية للاستيراد:",
        "import_denied": "كلمة مرور خاطئة. تم الإلغاء.",
        "backup_done": "تم إنشاء نسخة احتياطية مشفرة.",
        "backup_fail": "فشل النسخ الاحتياطي: {err}",
        "restore_bad": "لا يمكن فك الملف بهذه الكلمة الرئيسية.",
        "restored": "تمت الاستعادة.",
        "restore_fail": "فشل الاستعادة: {err}",
        "dlg_desc": "الوصف (مثال: Gmail):",
        "dlg_user": "المستخدم/الإيميل (اختياري):",
        "dlg_pwd": "كلمة السر:",
        "dlg_tags": "وسوم (مسافة بين كل وسم) – اختياري:",
        "dlg_notes": "ملاحظات – اختياري:",
        "dlg_length": "طول كلمة السر (8-64):",
        "dlg_inc_lower": "تضمين حروف صغيرة؟",
        "dlg_inc_upper": "تضمين حروف كبيرة؟",
        "dlg_inc_digits": "تضمين أرقام؟",
        "dlg_inc_symbols": "تضمين رموز؟",
        "panel_details": "تفاصيل",
        "footer": "صنع بواسطة MO1_1 و ChatGPT | الإصدار: {ver}",
        "locked": "مقفول",
        "master_short": "كلمة المرور الرئيسية:",
        "settings_title": "الإعدادات",
        "s_lang": "اللغة",
        "s_theme": "السمة",
        "s_idle": "القفل التلقائي (دقائق)",
        "s_clip": "مسح الحافظة (ثواني)",
        "s_reveal": "إخفاء العرض (ثواني)",
        "s_now": "الوقت والتاريخ الآن:",
        "apply": "تطبيق",
        "close": "إغلاق",
        "applied_msg": "تم حفظ الإعدادات وتطبيق اللغة/السمة.",
        "qr_title": "رمز QR",
        "qr_save": "حفظ كصورة",
        "tray_started": "تم الإرسال إلى الشريط. انقر الأيقونة لاستعادة.",
        "tray_unavail": "pystray غير مثبت. ميزات الشريط غير متاحة.",
        "qr_unavail": "حزمة qrcode غير مثبتة.",
        "mini_title": "MO1 Mini",
        "usergen": "يوزر نيم",
        "gen_user_title": "توليد يوزر نيم",
        "gen_user_len": "طول (6-20):",
    },
    "en": {
        "enter_master": "Enter master password:",
        "create_master": "Create a strong master password:",
        "confirm": "Confirm password:",
        "mismatch": "Passwords do not match.",
        "too_short": "Too short. Use at least 8 chars.",
        "need_crypto": "Requires 'cryptography'.\\npip install cryptography",
        "bad_master": "Invalid master password.",
        "sidebar_all": "All Items",
        "sidebar_tags": "Tags",
        "search": "Search… (use #tag to filter)",
        "add_manual": "Add",
        "generate": "Generate",
        "edit": "Edit",
        "delete": "Delete",
        "copy": "Copy",
        "copy_all": "Copy All",
        "reveal": "Reveal",
        "qr": "QR",
        "mini": "Mini",
        "tray": "To Tray",
        "lock": "Lock",
        "settings": "Settings",
        "import": "Import CSV",
        "export": "Export CSV",
        "backup": "Backup",
        "restore": "Restore",
        "desc": "Description",
        "user": "User/Email",
        "pwd_hidden": "Password (hidden)",
        "strength": "Strength",
        "created": "Created",
        "updated": "Updated",
        "notes": "Notes",
        "none": "—",
        "saved": "Saved.",
        "select_first": "Select a row first.",
        "delete_confirm": "Delete '{desc}'?",
        "need_pyperclip": "Need pyperclip for clipboard.\\npip install pyperclip",
        "copied": "Copied. Clipboard will clear in {sec}s.",
        "reveal_msg": "It will auto-hide in {sec}s.",
        "csv_exported": "CSV exported.",
        "csv_imported": "Imported: {n} entries.",
        "import_failed": "Import failed: {err}",
        "import_auth": "Enter master password to import:",
        "import_denied": "Wrong password. Cancelled.",
        "backup_done": "Encrypted backup created.",
        "backup_fail": "Backup failed: {err}",
        "restore_bad": "Can't decrypt with this master.",
        "restored": "Restored.",
        "restore_fail": "Restore failed: {err}",
        "dlg_desc": "Description (e.g., Gmail):",
        "dlg_user": "User/Email (optional):",
        "dlg_pwd": "Password:",
        "dlg_tags": "Tags (space separated) – optional:",
        "dlg_notes": "Notes – optional:",
        "dlg_length": "Password length (8-64):",
        "dlg_inc_lower": "Include lowercase?",
        "dlg_inc_upper": "Include uppercase?",
        "dlg_inc_digits": "Include digits?",
        "dlg_inc_symbols": "Include symbols?",
        "panel_details": "Details",
        "footer": "Made by MO1_1 & ChatGPT | Version: {ver}",
        "locked": "Locked",
        "master_short": "Master password:",
        "settings_title": "Settings",
        "s_lang": "Language",
        "s_theme": "Theme",
        "s_idle": "Auto-lock (minutes)",
        "s_clip": "Clipboard clear (seconds)",
        "s_reveal": "Auto-hide reveal (seconds)",
        "s_now": "Now (date & time):",
        "apply": "Apply",
        "close": "Close",
        "applied_msg": "Settings saved. Language/Theme applied.",
        "qr_title": "QR Code",
        "qr_save": "Save as Image",
        "tray_started": "Sent to tray. Click icon to restore.",
        "tray_unavail": "pystray not installed. Tray unavailable.",
        "qr_unavail": "qrcode package not installed.",
        "mini_title": "MO1 Mini",
        "usergen": "Username",
        "gen_user_title": "Username Generator",
        "gen_user_len": "Length (6-20):",
    }
}

def tr(lang, key, **kw): return T[lang][key].format(**kw)

from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet, InvalidToken
from pathlib import Path

def pbkdf2_key(password: str, salt: bytes, length=32, iterations=200000) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=length, salt=salt, iterations=iterations, backend=default_backend())
    return kdf.derive(password.encode("utf-8"))

def derive_fernet_key(master_password: str, salt: bytes) -> bytes:
    raw = pbkdf2_key(master_password, salt, length=32)
    return base64.urlsafe_b64encode(raw)

def load_config():
    if CONF_FILE.exists():
        try: cfg = json.loads(CONF_FILE.read_text(encoding="utf-8"))
        except Exception: cfg = {}
    else: cfg = {}
    for k,v in DEFAULTS.items(): cfg.setdefault(k, v)
    return cfg

def save_config(cfg: dict):
    CONF_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

def setup_master_password(lang):
    cfg = load_config()
    if "salt" in cfg and "hash" in cfg: return True
    if not CRYPTO_OK:
        messagebox.showerror(app_title(lang), tr(lang,"need_crypto")); return False
    while True:
        p1 = simpledialog.askstring(app_title(lang), tr(lang,"create_master"), show="*")
        if not p1: return False
        p2 = simpledialog.askstring(app_title(lang), tr(lang,"confirm"), show="*")
        if p1 != p2:
            messagebox.showwarning(app_title(lang), tr(lang,"mismatch")); continue
        if len(p1) < 8:
            messagebox.showwarning(app_title(lang), tr(lang,"too_short")); continue
        salt = os.urandom(16); key = pbkdf2_key(p1, salt, length=32)
        cfg["salt"] = base64.b64encode(salt).decode(); cfg["hash"] = base64.b64encode(key).decode()
        save_config(cfg); return True

def verify_master(master_password: str):
    cfg = load_config()
    salt_b64 = cfg.get("salt"); hash_b64 = cfg.get("hash")
    if not (salt_b64 and hash_b64): return False, None
    salt = base64.b64decode(salt_b64.encode())
    try:
        key = pbkdf2_key(master_password, salt, length=32)
        ok = base64.b64encode(key).decode() == hash_b64
        if not ok: return False, None
        f = Fernet(derive_fernet_key(master_password, salt))
        return True, f
    except Exception:
        return False, None

def decrypt_db(fernet: "Fernet") -> list:
    if not DB_FILE.exists(): return []
    try:
        data = DB_FILE.read_bytes()
        payload = fernet.decrypt(data)
        return json.loads(payload.decode("utf-8"))
    except InvalidToken:
        return None
    except Exception:
        return []

def encrypt_db(fernet: "Fernet", items: list):
    payload = json.dumps(items, ensure_ascii=False, indent=2).encode("utf-8")
    token = fernet.encrypt(payload)
    DB_FILE.write_bytes(token)

def generate_password(length=16, lowercase=True, uppercase=True, digits=True, symbols=True):
    pools = []
    if lowercase: pools.append(string.ascii_lowercase)
    if uppercase: pools.append(string.ascii_uppercase)
    if digits: pools.append(string.digits)
    if symbols: pools.append("!@#$%^&*()-_=+[]{};:,<.>/?")
    if not pools: pools = [string.ascii_letters + string.digits]
    pwd_chars = [random.choice(p) for p in pools]
    allchars = "".join(pools)
    while len(pwd_chars) < length: pwd_chars.append(random.choice(allchars))
    random.shuffle(pwd_chars)
    return "".join(pwd_chars[:length])

def password_strength(pwd: str):
    score = 0; length=len(pwd)
    diversity = sum([any(c.islower() for c in pwd),
                     any(c.isupper() for c in pwd),
                     any(c.isdigit() for c in pwd),
                     any(c in "!@#$%^&*()-_=+[]{};:,<.>/?\\" for c in pwd)])
    if length >= 16: score += 2
    elif length >= 12: score += 1
    if diversity >= 3: score += 2
    elif diversity == 2: score += 1
    if pwd.lower() in WEAK_PASSWORDS: score = max(score-2, 0)
    if score >= 4: return "strong"
    if score >= 2: return "medium"
    return "weak"

def app_title(lang): return APP_NAME_AR if lang=="ar" else APP_NAME_EN
def now_iso(): return datetime.utcnow().isoformat() + "Z"

def generate_username(length=10):
    base = "MO1"
    pool = string.ascii_lowercase + string.ascii_uppercase + string.digits
    core = "".join(random.choice(pool) for _ in range(max(3, length-len(base))))
    return base + core

def show_splash(root, colors, lang):
    splash = tk.Toplevel(root)
    splash.overrideredirect(True)
    w, h = 360, 220
    sw = root.winfo_screenwidth(); sh = root.winfo_screenheight()
    x = (sw - w)//2; y = (sh - h)//2
    splash.geometry(f"{w}x{h}+{x}+{y}")
    splash.configure(bg="#0b1220")
    lbl1 = tk.Label(splash, text="🔒", bg="#0b1220", fg="white", font=("Segoe UI", 36, "bold"))
    lbl1.pack(pady=(24, 6))
    lbl2 = tk.Label(splash, text="Made by MO1_1 & ChatGPT", bg="#0b1220", fg="white", font=("Segoe UI", 14))
    lbl2.pack()
    lbl3 = tk.Label(splash, text=("الإصدار: " if lang=="ar" else "Version: ")+VERSION, bg="#0b1220", fg="white", font=("Segoe UI", 12))
    lbl3.pack(pady=(6, 0))
    splash.attributes("-alpha", 0.0)
    for i in range(0, 11):
        splash.attributes("-alpha", i/10.0)
        splash.update(); time.sleep(0.05)
    time.sleep(1.2)
    for i in range(10, -1, -1):
        splash.attributes("-alpha", i/10.0)
        splash.update(); time.sleep(0.04)
    splash.destroy()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.lang = self.cfg.get("lang","en")
        self.theme = self.cfg.get("theme","blue")
        self.idle_minutes = int(self.cfg.get("idle_minutes",5))
        self.clipboard_seconds = int(self.cfg.get("clipboard_seconds",30))
        self.reveal_seconds = int(self.cfg.get("reveal_seconds",5))
        self.last_activity = time.time()
        self.is_locked = False
        self.fernet = None
        self.items = []
        self.current_tag_filter = None
        self.tray_icon = None

        self.title(app_title(self.lang))
        self.state("zoomed")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.apply_theme()

        self.withdraw()
        self.after(50, self.auth_then_start)

    def apply_theme(self):
        style = ttk.Style()
        try: style.theme_use("clam")
        except: pass
        if self.theme == "blue":
            bg="#0b1220"; fg="#dbeafe"; ac="#111827"; card="#0f172a"; sel="#1d4ed8"
        elif self.theme == "dark":
            bg="#0f1115"; fg="#e5e7eb"; ac="#111318"; card="#151922"; sel="#374151"
        else:
            bg="#ffffff"; fg="#1f2937"; ac="#f3f4f6"; card="#f8fafc"; sel="#cbd5e1"
        self.colors = dict(bg=bg, fg=fg, ac=ac, card=card, sel=sel)
        self.configure(bg=bg)
        style.configure(".", background=bg, foreground=fg, fieldbackground=ac)
        style.configure("Treeview", background=card, foreground=fg, fieldbackground=card, rowheight=28)
        style.map("Treeview", background=[("selected", sel)])

    def auth_then_start(self):
        show_splash(self, self.colors, self.lang)
        if not CRYPTO_OK:
            messagebox.showerror(app_title(self.lang), tr(self.lang,"need_crypto")); self.destroy(); return
        if not setup_master_password(self.lang): self.destroy(); return
        while True:
            p = simpledialog.askstring(app_title(self.lang), tr(self.lang,"enter_master"), show="*")
            if p is None: self.destroy(); return
            ok, f = verify_master(p)
            if ok:
                self.fernet = f
                data = decrypt_db(self.fernet)
                if data is None: messagebox.showerror(app_title(self.lang), tr(self.lang,"bad_master")); continue
                self.items = data; break
            else:
                messagebox.showerror(app_title(self.lang), tr(self.lang,"bad_master"))
        self.deiconify(); self.build_layout(); self.refresh_all()
        threading.Thread(target=self.idle_checker, daemon=True).start()

    def lock(self):
        if self.is_locked: return
        self.is_locked = True; self.withdraw()
        while True:
            p = simpledialog.askstring(tr(self.lang,"locked"), tr(self.lang,"master_short"), show="*")
            if p is None: continue
            ok, f = verify_master(p)
            if ok:
                self.fernet = f; data = decrypt_db(self.fernet)
                if data is not None:
                    self.items = data; self.last_activity=time.time(); self.is_locked=False; self.deiconify(); break
            else:
                messagebox.showerror(app_title(self.lang), tr(self.lang,"bad_master"))

    def on_activity(self, _=None): self.last_activity = time.time()
    def idle_checker(self):
        while True:
            time.sleep(5)
            if self.is_locked: continue
            if (time.time() - self.last_activity) > (self.idle_minutes*60):
                self.after(0, self.lock)

    def build_layout(self):
        for w in self.winfo_children(): w.destroy()
        for seq in ("<Key>", "<Button-1>", "<Motion>"): self.bind_all(seq, self.on_activity)

        root = ttk.Frame(self, padding=0); root.pack(fill=tk.BOTH, expand=True)
        root.columnconfigure(0, weight=0); root.columnconfigure(1, weight=3); root.columnconfigure(2, weight=2)
        root.rowconfigure(0, weight=1); root.rowconfigure(1, weight=0)

        side = ttk.Frame(root); side.grid(row=0, column=0, sticky="nsw", padx=8, pady=8)
        def side_button(txt, cmd):
            b = tk.Button(side, text=txt, command=cmd, bd=0, relief="flat",
                          fg=self.colors["fg"], bg=self.colors["card"], activebackground=self.colors["sel"],
                          activeforeground="white", padx=12, pady=10, font=("Segoe UI", 10, "bold"))
            b.pack(fill=tk.X, pady=4); return b
        side_button("🗂  " + tr(self.lang,"sidebar_all"), lambda: self.set_tag_filter(None))
        ttk.Label(side, text=tr(self.lang,"sidebar_tags")).pack(anchor="w", pady=(12,4))
        self.tags_list = tk.Listbox(side, height=12, bg=self.colors["card"], fg=self.colors["fg"], bd=0, highlightthickness=0)
        self.tags_list.pack(fill=tk.BOTH, expand=True); self.tags_list.bind("<<ListboxSelect>>", self.on_tag_select)

        mid = ttk.Frame(root); mid.grid(row=0, column=1, sticky="nsew", padx=8, pady=8)
        toolbar = ttk.Frame(mid); toolbar.pack(fill=tk.X)
        def tool_btn(txt, cmd):
            return tk.Button(toolbar, text=txt, command=cmd, bd=0, relief="flat",
                             fg=self.colors["fg"], bg=self.colors["card"], activebackground=self.colors["sel"],
                             activeforeground="white", padx=10, pady=8, font=("Segoe UI", 10))
        tool_btn("➕ " + tr(self.lang,"add_manual"), self.add_manual_dialog).pack(side=tk.LEFT, padx=4)
        tool_btn("🎲 " + tr(self.lang,"generate"), self.add_password_dialog).pack(side=tk.LEFT, padx=4)
        tool_btn("🖊 " + tr(self.lang,"edit"), self.edit_selected).pack(side=tk.LEFT, padx=4)
        tool_btn("❌ " + tr(self.lang,"delete"), self.delete_selected).pack(side=tk.LEFT, padx=4)
        tool_btn("📋 " + tr(self.lang,"copy"), self.copy_selected).pack(side=tk.LEFT, padx=4)
        tool_btn("📄 " + tr(self.lang,"copy_all"), self.copy_all_selected).pack(side=tk.LEFT, padx=4)
        tool_btn("👁 " + tr(self.lang,"reveal"), self.reveal_selected).pack(side=tk.LEFT, padx=4)
        tool_btn("🔳 " + tr(self.lang,"qr"), self.qr_selected).pack(side=tk.LEFT, padx=4)
        tool_btn("🧑 " + tr(self.lang,"usergen"), self.username_generator).pack(side=tk.LEFT, padx=4)
        tool_btn("🔒 " + tr(self.lang,"lock"), self.lock).pack(side=tk.RIGHT, padx=4)
        tool_btn("⚙️ " + tr(self.lang,"settings"), self.open_settings).pack(side=tk.RIGHT, padx=4)
        tool_btn("🗔 " + tr(self.lang,"mini"), self.open_mini).pack(side=tk.RIGHT, padx=4)
        tool_btn("🖥 " + tr(self.lang,"tray"), self.to_tray).pack(side=tk.RIGHT, padx=4)

        self.search_var = tk.StringVar()
        search = ttk.Entry(mid, textvariable=self.search_var, width=40)
        search.insert(0, tr(self.lang,"search"))
        search.bind("<FocusIn>", lambda e: (self.search_var.set("") if self.search_var.get()==tr(self.lang,"search") else None))
        self.search_var.trace_add("write", lambda *a: self.refresh_list())
        search.pack(fill=tk.X, pady=8)

        cols=("desc","user","masked","strength","created","updated")
        self.tree = ttk.Treeview(mid, columns=cols, show="headings")
        for c in cols: self.tree.heading(c, text=tr(self.lang, {"desc":"desc","user":"user","masked":"pwd_hidden","strength":"strength","created":"created","updated":"updated"}[c]))
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", lambda e: self.copy_selected())
        self.tree.tag_configure("weak", foreground="#ef4444")
        self.tree.tag_configure("medium", foreground="#f59e0b")
        self.tree.tag_configure("strong", foreground="#22c55e")

        right = ttk.Frame(root); right.grid(row=0, column=2, sticky="nsew", padx=8, pady=8)
        ttk.Label(right, text=tr(self.lang,"panel_details")).pack(anchor="w", pady=(0,8))
        self.d_desc = tk.StringVar(value=tr(self.lang,"none"))
        self.d_user = tk.StringVar(value=tr(self.lang,"none"))
        self.d_pwd = tk.StringVar(value="••••••••")
        self.d_strength = tk.StringVar(value=tr(self.lang,"none"))
        self.d_created = tk.StringVar(value=tr(self.lang,"none"))
        self.d_updated = tk.StringVar(value=tr(self.lang,"none"))
        self.d_notes = tk.StringVar(value=tr(self.lang,"none"))
        def row(label, var):
            f = ttk.Frame(right); f.pack(fill=tk.X, pady=2)
            ttk.Label(f, text=label+":").pack(side=tk.LEFT); ttk.Label(f, textvariable=var).pack(side=tk.RIGHT)
        row(tr(self.lang,"desc"), self.d_desc)
        row(tr(self.lang,"user"), self.d_user)
        row(tr(self.lang,"strength"), self.d_strength)
        row(tr(self.lang,"created"), self.d_created)
        row(tr(self.lang,"updated"), self.d_updated)
        nf = ttk.Frame(right); nf.pack(fill=tk.BOTH, expand=True, pady=(6,0))
        ttk.Label(nf, text=tr(self.lang,"notes")+":").pack(anchor="w")
        self.notes_label = tk.Label(nf, textvariable=self.d_notes, justify="left", wraplength=360, bg=self.colors["card"], fg=self.colors["fg"], padx=8, pady=8)
        self.notes_label.pack(fill=tk.BOTH, expand=True)

        foot = ttk.Frame(root); foot.grid(row=1, column=0, columnspan=3, sticky="ew", padx=10, pady=(0,8))
        self.footer_var = tk.StringVar(value=tr(self.lang,"footer", ver=VERSION))
        ttk.Label(foot, textvariable=self.footer_var).pack(side=tk.RIGHT)

    def set_tag_filter(self, tag): self.current_tag_filter = tag; self.refresh_all()
    def on_tag_select(self, _):
        sel = self.tags_list.curselection()
        if not sel: return
        tag = self.tags_list.get(sel[0]); self.set_tag_filter(tag)

    def parse_search(self):
        q = (getattr(self, "search_var", tk.StringVar(value="")).get() or "").strip()
        if not q or q == tr(self.lang,"search"): return "", None
        tokens = q.split()
        tags = [t[1:] for t in tokens if t.startswith("#") and len(t)>1]
        keywords = " ".join([t for t in tokens if not t.startswith("#")])
        tag = tags[0] if tags else None
        return keywords.lower(), tag

    def filtered_items(self):
        kw, tag = self.parse_search()
        items = self.items
        if self.current_tag_filter: tag = self.current_tag_filter
        if tag:
            items = [i for i in items if tag in i.get("tags",[])]
        if kw:
            items = [i for i in items if kw in i["desc"].lower() or kw in i.get("user","").lower() or kw in i.get("notes","").lower()]
        return sorted(items, key=lambda x: x["desc"].lower())

    def refresh_tags(self):
        tags = set()
        for i in self.items:
            for t in i.get("tags",[]): tags.add(t)
        self.tags_list.delete(0, tk.END)
        for t in sorted(tags): self.tags_list.insert(tk.END, t)

    def refresh_list(self):
        for r in self.tree.get_children(): self.tree.delete(r)
        for i in self.filtered_items():
            lvl = password_strength(i["pwd"])
            lvl_text = {"ar":{"weak":"ضعيف 🔴","medium":"متوسط 🟡","strong":"قوي 🟢"},
                        "en":{"weak":"Weak 🔴","medium":"Medium 🟡","strong":"Strong 🟢"}}[self.lang][lvl]
            masked = "•"*min(len(i["pwd"]),12)
            self.tree.insert("", tk.END, values=(i["desc"], i.get("user",""), masked, lvl_text, i.get("created_at","")[:10], i.get("updated_at","")[:10]), tags=(lvl,))
        self.set_details(None)

    def refresh_all(self):
        self.refresh_tags(); self.refresh_list()

    def set_details(self, item):
        if not item:
            self.d_desc.set(tr(self.lang,"none")); self.d_user.set(tr(self.lang,"none"))
            self.d_pwd.set("••••••••"); self.d_strength.set(tr(self.lang,"none"))
            self.d_created.set(tr(self.lang,"none")); self.d_updated.set(tr(self.lang,"none"))
            self.d_notes.set(tr(self.lang,"none")); return
        lvl = password_strength(item["pwd"])
        lvl_text = {"ar":{"weak":"ضعيف 🔴","medium":"متوسط 🟡","strong":"قوي 🟢"},
                    "en":{"weak":"Weak 🔴","medium":"Medium 🟡","strong":"Strong 🟢"}}[self.lang][lvl]
        self.d_desc.set(item["desc"]); self.d_user.set(item.get("user","") or tr(self.lang,"none"))
        self.d_pwd.set("•"*len(item["pwd"])); self.d_strength.set(lvl_text)
        self.d_created.set(item.get("created_at","")[:19]); self.d_updated.set(item.get("updated_at","")[:19])
        self.d_notes.set(item.get("notes","") or tr(self.lang,"none"))

    def get_selected_item(self):
        sel = self.tree.selection()
        if not sel: messagebox.showwarning(app_title(self.lang), tr(self.lang,"select_first")); return None
        desc = self.tree.item(sel[0], "values")[0]
        return next((x for x in self.items if x["desc"]==desc), None)

    def on_select(self, _=None):
        it = self.get_selected_item()
        if it: self.set_details(it)

    def add_manual_dialog(self):
        desc = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_desc"))
        if not desc: return
        user = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_user")) or ""
        pwd = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_pwd"), show="*")
        if not pwd: return
        tags_str = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_tags")) or ""
        notes = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_notes")) or ""
        tags = [t for t in tags_str.split() if t]
        item = {"desc":desc,"user":user,"pwd":pwd,"tags":tags,"notes":notes,"created_at":now_iso(),"updated_at":now_iso()}
        self.items.append(item); encrypt_db(self.fernet, self.items); self.refresh_all()
        messagebox.showinfo(app_title(self.lang), tr(self.lang,"saved"))

    def add_password_dialog(self):
        desc = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_desc"))
        if not desc: return
        length = simpledialog.askinteger(app_title(self.lang), tr(self.lang,"dlg_length"), minvalue=8, maxvalue=64, initialvalue=16)
        if not length: return
        inc_l = messagebox.askyesno(app_title(self.lang), tr(self.lang,"dlg_inc_lower"))
        inc_u = messagebox.askyesno(app_title(self.lang), tr(self.lang,"dlg_inc_upper"))
        inc_d = messagebox.askyesno(app_title(self.lang), tr(self.lang,"dlg_inc_digits"))
        inc_s = messagebox.askyesno(app_title(self.lang), tr(self.lang,"dlg_inc_symbols"))
        pwd = generate_password(length, inc_l, inc_u, inc_d, inc_s)
        user = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_user")) or ""
        tags_str = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_tags")) or ""
        notes = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_notes")) or ""
        tags = [t for t in tags_str.split() if t]
        item = {"desc":desc,"user":user,"pwd":pwd,"tags":tags,"notes":notes,"created_at":now_iso(),"updated_at":now_iso()}
        self.items.append(item); encrypt_db(self.fernet, self.items); self.refresh_all()
        messagebox.showinfo(app_title(self.lang), tr(self.lang,"saved"))

    def edit_selected(self):
        item = self.get_selected_item()
        if not item: return
        new_desc = simpledialog.askstring(app_title(self.lang), tr(self.lang,"desc"), initialvalue=item["desc"])
        if new_desc: item["desc"] = new_desc
        new_user = simpledialog.askstring(app_title(self.lang), tr(self.lang,"user"), initialvalue=item.get("user",""))
        if new_user is not None: item["user"] = new_user
        new_notes = simpledialog.askstring(app_title(self.lang), tr(self.lang,"notes"), initialvalue=item.get("notes",""))
        if new_notes is not None: item["notes"] = new_notes
        tags_str = simpledialog.askstring(app_title(self.lang), tr(self.lang,"dlg_tags"), initialvalue=" ".join(item.get("tags",[])) or "")
        if tags_str is not None: item["tags"] = [t for t in tags_str.split() if t]
        item["updated_at"] = now_iso(); encrypt_db(self.fernet, self.items); self.refresh_all()

    def delete_selected(self):
        item = self.get_selected_item()
        if not item: return
        if messagebox.askyesno(app_title(self.lang), tr(self.lang,"delete_confirm", desc=item['desc'])):
            self.items = [i for i in self.items if i is not item]
            encrypt_db(self.fernet, self.items); self.refresh_all()

    def copy_selected(self):
        if pyperclip is None:
            messagebox.showerror(app_title(self.lang), tr(self.lang,"need_pyperclip")); return
        item = self.get_selected_item()
        if not item: return
        pyperclip.copy(item["pwd"])
        secs = int(self.clipboard_seconds)
        messagebox.showinfo(app_title(self.lang), tr(self.lang,"copied", sec=secs))
        threading.Thread(target=self._clear_clipboard_after, args=(secs,), daemon=True).start()

    def copy_all_selected(self):
        if pyperclip is None:
            messagebox.showerror(app_title(self.lang), tr(self.lang,"need_pyperclip")); return
        item = self.get_selected_item()
        if not item: return
        text = f"{tr(self.lang,'desc')}: {item['desc']}\\n{tr(self.lang,'user')}: {item.get('user','')}\\nPassword: {item['pwd']}"
        pyperclip.copy(text)
        secs = int(self.clipboard_seconds)
        messagebox.showinfo(app_title(self.lang), tr(self.lang,"copied", sec=secs))
        threading.Thread(target=self._clear_clipboard_after, args=(secs,), daemon=True).start()

    def _clear_clipboard_after(self, secs):
        time.sleep(secs)
        try:
            if pyperclip: pyperclip.copy("")
        except: pass

    def reveal_selected(self):
        item = self.get_selected_item()
        if not item: return
        secs = int(self.reveal_seconds)
        messagebox.showinfo(app_title(self.lang), tr(self.lang,"reveal_msg", sec=secs))
        self.d_pwd.set(item["pwd"])
        def hide_cb(): time.sleep(secs); self.d_pwd.set("•"*len(item["pwd"]))
        threading.Thread(target=hide_cb, daemon=True).start()

    def qr_selected(self):
        if not QR_OK:
            messagebox.showerror(app_title(self.lang), tr(self.lang,"qr_unavail")); return
        item = self.get_selected_item()
        if not item: return
        data = item["pwd"]
        img = qrcode.make(data)
        top = tk.Toplevel(self); top.title(tr(self.lang,"qr_title"))
        bio = io.BytesIO(); img.save(bio, format="PNG"); bio.seek(0)
        image = Image.open(bio); tkimg = ImageTk.PhotoImage(image)
        lbl = tk.Label(top, image=tkimg); lbl.image = tkimg; lbl.pack(padx=8, pady=8)
        def save_png():
            p = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG","*.png")])
            if not p: return
            img.save(p, "PNG")
        ttk.Button(top, text=tr(self.lang,"qr_save"), command=save_png).pack(pady=(0,8))

    def username_generator(self):
        length = simpledialog.askinteger(app_title(self.lang), tr(self.lang,"gen_user_len"), minvalue=6, maxvalue=20, initialvalue=10)
        if not length: return
        uname = generate_username(length)
        if pyperclip:
            pyperclip.copy(uname)
            messagebox.showinfo(tr(self.lang,"gen_user_title"), f"{uname}\\n\\n{tr(self.lang,'copied', sec=self.clipboard_seconds)}")
            threading.Thread(target=self._clear_clipboard_after, args=(self.clipboard_seconds,), daemon=True).start()
        else:
            messagebox.showinfo(tr(self.lang,"gen_user_title"), uname)

    def export_csv(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")])
        if not path: return
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["desc","user","pwd","tags","notes","created_at","updated_at"])
            for i in self.items:
                w.writerow([i["desc"], i.get("user",""), i["pwd"], " ".join(i.get("tags",[])), i.get("notes",""), i.get("created_at",""), i.get("updated_at","")])
        messagebox.showinfo(app_title(self.lang), tr(self.lang,"csv_exported"))

    def import_csv(self):
        p = simpledialog.askstring(app_title(self.lang), tr(self.lang,"import_auth"), show="*")
        if p is None: return
        ok, _ = verify_master(p)
        if not ok: messagebox.showerror(app_title(self.lang), tr(self.lang,"import_denied")); return
        path = filedialog.askopenfilename(filetypes=[("CSV","*.csv")])
        if not path: return
        try:
            added=0
            with open(path, newline="", encoding="utf-8") as f:
                r = csv.DictReader(f)
                for row in r:
                    desc=row.get("desc") or ""; pwd=row.get("pwd") or ""
                    if not desc or not pwd: continue
                    user=row.get("user") or ""
                    tags=(row.get("tags") or "").split()
                    notes=row.get("notes") or ""
                    self.items.append({
                        "desc":desc,"user":user,"pwd":pwd,"tags":tags,"notes":notes,
                        "created_at": row.get("created_at") or now_iso(),
                        "updated_at": row.get("updated_at") or now_iso()
                    }); added+=1
            encrypt_db(self.fernet, self.items); self.refresh_all()
            messagebox.showinfo(app_title(self.lang), tr(self.lang,"csv_imported", n=added))
        except Exception as e:
            messagebox.showerror(app_title(self.lang), tr(self.lang,"import_failed", err=e))

    def backup(self):
        path = filedialog.asksaveasfilename(defaultextension=BACKUP_EXT, filetypes=[("Password Manager Backup", f"*{BACKUP_EXT}")])
        if not path: return
        try:
            with open(path, "wb") as out:
                out.write(DB_FILE.read_bytes() if DB_FILE.exists() else b"")
            messagebox.showinfo(app_title(self.lang), tr(self.lang,"backup_done"))
        except Exception as e:
            messagebox.showerror(app_title(self.lang), tr(self.lang,"backup_fail", err=e))

    def restore(self):
        path = filedialog.askopenfilename(filetypes=[("Password Manager Backup", f"*{BACKUP_EXT}")])
        if not path: return
        try:
            data = Path(path).read_bytes()
            try: json.loads(self.fernet.decrypt(data).decode("utf-8"))
            except Exception: messagebox.showerror(app_title(self.lang), tr(self.lang,"restore_bad")); return
            DB_FILE.write_bytes(data)
            self.items = json.loads(self.fernet.decrypt(data).decode("utf-8"))
            self.refresh_all(); messagebox.showinfo(app_title(self.lang), tr(self.lang,"restored"))
        except Exception as e:
            messagebox.showerror(app_title(self.lang), tr(self.lang,"restore_fail", err=e))

    def open_settings(self):
        d = tk.Toplevel(self); d.title(tr(self.lang,"settings_title")); d.geometry("460x360"); d.resizable(False, False)
        frm = ttk.Frame(d); frm.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        ttk.Label(frm, text=tr(self.lang,"s_lang")).grid(row=0, column=0, sticky="w", pady=4)
        lang_var = tk.StringVar(value=self.lang)
        ttk.Radiobutton(frm, text="العربية", variable=lang_var, value="ar").grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(frm, text="English", variable=lang_var, value="en").grid(row=0, column=2, sticky="w")

        ttk.Label(frm, text=tr(self.lang,"s_theme")).grid(row=1, column=0, sticky="w", pady=4)
        theme_var = tk.StringVar(value=self.theme)
        ttk.Radiobutton(frm, text="Light", variable=theme_var, value="light").grid(row=1, column=1, sticky="w")
        ttk.Radiobutton(frm, text="Dark", variable=theme_var, value="dark").grid(row=1, column=2, sticky="w")
        ttk.Radiobutton(frm, text="Blue Dark", variable=theme_var, value="blue").grid(row=1, column=3, sticky="w")

        ttk.Label(frm, text=tr(self.lang,"s_idle")).grid(row=2, column=0, sticky="w", pady=6)
        idle_var = tk.IntVar(value=self.idle_minutes); ttk.Entry(frm, textvariable=idle_var, width=8).grid(row=2, column=1, sticky="w")
        ttk.Label(frm, text=tr(self.lang,"s_clip")).grid(row=3, column=0, sticky="w", pady=6)
        clip_var = tk.IntVar(value=self.clipboard_seconds); ttk.Entry(frm, textvariable=clip_var, width=8).grid(row=3, column=1, sticky="w")
        ttk.Label(frm, text=tr(self.lang,"s_reveal")).grid(row=4, column=0, sticky="w", pady=6)
        rev_var = tk.IntVar(value=self.reveal_seconds); ttk.Entry(frm, textvariable=rev_var, width=8).grid(row=4, column=1, sticky="w")

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ttk.Label(frm, text=tr(self.lang,"s_now")).grid(row=5, column=0, sticky="w", pady=(10,4))
        ttk.Label(frm, text=now_str).grid(row=5, column=1, sticky="w")

        btns = ttk.Frame(frm); btns.grid(row=6, column=0, columnspan=4, pady=14, sticky="e")

        def apply_changes():
            self.lang = lang_var.get()
            self.theme = theme_var.get()
            self.idle_minutes = max(1, int(idle_var.get()))
            self.clipboard_seconds = max(1, int(clip_var.get()))
            self.reveal_seconds = max(1, int(rev_var.get()))
            cfg = load_config()
            cfg.update(dict(lang=self.lang, theme=self.theme, idle_minutes=self.idle_minutes,
                            clipboard_seconds=self.clipboard_seconds, reveal_seconds=self.reveal_seconds))
            save_config(cfg)
            self.apply_theme()
            self.title(app_title(self.lang))
            messagebox.showinfo(app_title(self.lang), tr(self.lang,"applied_msg"))
            self.build_layout(); self.refresh_all()

        ttk.Button(btns, text=tr(self.lang,"apply"), command=apply_changes).pack(side=tk.RIGHT, padx=6)
        ttk.Button(btns, text=tr(self.lang,"close"), command=d.destroy).pack(side=tk.RIGHT)

    def open_mini(self):
        mini = tk.Toplevel(self); mini.title(tr(self.lang,"mini_title"))
        mini.geometry("360x420"); mini.resizable(False, False); mini.configure(bg=self.colors["bg"])
        q = tk.StringVar()
        e = ttk.Entry(mini, textvariable=q); e.pack(fill=tk.X, padx=8, pady=8)
        lst = tk.Listbox(mini, bg=self.colors["card"], fg=self.colors["fg"]); lst.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

        def update_list(*a):
            kw = q.get().strip().lower()
            lst.delete(0, tk.END)
            for it in sorted(self.items, key=lambda x:x["desc"].lower()):
                if not kw or kw in it["desc"].lower() or kw in (it.get("user","").lower()):
                    lst.insert(tk.END, it["desc"])
        q.trace_add("write", update_list); update_list()

        def copy_selected_mini(_=None):
            sel = lst.curselection()
            if not sel or pyperclip is None: return
            desc = lst.get(sel[0])
            it = next((x for x in self.items if x["desc"]==desc), None)
            if not it: return
            pyperclip.copy(it["pwd"]); threading.Thread(target=self._clear_clipboard_after, args=(self.clipboard_seconds,), daemon=True).start()
            mini.bell()

        lst.bind("<Double-1>", copy_selected_mini)

    def to_tray(self):
        if not TRAY_OK:
            messagebox.showwarning(app_title(self.lang), tr(self.lang,"tray_unavail")); return
        self.withdraw()
        icon_img = PILImage.new("RGBA", (64,64), (11,18,32,255))
        d = ImageDraw.Draw(icon_img)
        d.ellipse((16,16,48,48), fill=(139,92,246,255))
        d.rectangle((22,30,42,46), fill=(255,255,255,255))
        def on_restore(icon, item):
            icon.stop()
            self.deiconify(); self.lift(); self.focus_force()
        def on_exit(icon, item):
            icon.stop(); self.after(100, self.destroy)
        menu = (pystray.MenuItem("Restore", on_restore), pystray.MenuItem("Exit", on_exit))
        self.tray_icon = pystray.Icon("MO1", icon_img, "MO1 Password Manager", menu)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()
        messagebox.showinfo(app_title(self.lang), tr(self.lang,"tray_started"))

    def on_close(self):
        if getattr(self, "tray_icon", None):
            try: self.tray_icon.stop()
            except: pass
        self.destroy()

def main(): App().mainloop()
if __name__ == "__main__": main()

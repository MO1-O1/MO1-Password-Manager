#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import tkinter as tk
from PIL import ImageTk

import password_manager_v2 as app

APP_TITLE = "MO1"

orig_init = app.App.__init__
def patched_init(self, *a, **kw):
    orig_init(self, *a, **kw)
    self.title(APP_TITLE)
    try:
        self.iconphoto(False, ImageTk.PhotoImage(file="app_icon.png"))
    except Exception:
        try:
            self.iconbitmap("app_icon.ico")
        except Exception:
            pass

app.App.__init__ = patched_init
app.main()
